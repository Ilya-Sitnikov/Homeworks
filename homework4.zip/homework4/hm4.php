<!doctype html>
<html lang="en">
<head>
  <title>Homework4</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
  
<body> 
    <div class="container mt-2"> 
  
<div class="modal-body">
<select required id="name" class="text-success form-control input-sm">
<option class="text-success" selected disabled value=""><h6>Выбрать цвет</h6>
</option>
	<option class="text-success text-center" value="Чёрный">Чёрный</option>
	<option class="text-success text-center" value="Белый">Белый</option>
	<option class="text-success text-center" value="Красный">Красный</option>
	<option class="text-success text-center" value="Синий">Синий</option>
</select>
   
</div>
					  
<div class="modal-body">
<select required id="marks" class="text-success form-control input-sm">
<option class="text-success" selected disabled value=""><h6>Выбрать марку</h6></option>
	<option class="text-success text-center" value="Ford">Ford</option>
	<option class="text-success text-center" value="Audi">Audi</option>
	<option class="text-success text-center" value="Mercedes">Mercedes</option>
	<option class="text-success text-center" value="Toyota">Toyota</option>
</select>
   
</div>
  
<button type="button" class="btn btn-primary  btn-sm" data-toggle="modal" data-target="#Modal"id="submit">Подтвердить</button> 
  
<div class="modal fade" id="Modal"tabindex="-1"aria-labelledby="ModalLabel"aria-hidden="true"> 
    <div class="modal-dialog"> 
		<div class="modal-content"> 
			<div class="modal-header"> 
<h5 class="modal-title"id="ModalLabel">Подтверждение</h5> 
                          
<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true"> × </span> </button> 
</div> 
  
<div class="modal-body"> 
  
<h6 id="modal_body"></h6> 
<button type="button" class="btn btn-success btn-sm" data-toggle="modal"data-target="#Modal" id="submit"> Submit </button> 
				</div> 
			</div> 
		</div> 
	</div> 
</div> 
  
    <script type="text/javascript"> 
        $("#submit").click(function () { 
            var name = $("#name").val(); 
            var marks = $("#marks").val(); 
            var str = "Вы выбрали " + "цвет: " + name + " и марку: " + marks; 
            $("#modal_body").html(str); 
        }); 
    </script> 
	
</body> 
</html> 