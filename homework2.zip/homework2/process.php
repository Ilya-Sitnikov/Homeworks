<?php
include('connect.php');
if (isset($_POST["create"])) {
    $faculty_id = mysqli_real_escape_string($conn, $_POST["faculty_id"]);
    $type = mysqli_real_escape_string($conn, $_POST["type"]);
    $author = mysqli_real_escape_string($conn, $_POST["author"]);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);
    $sqlInsert = "INSERT INTO books(faculty_id , author , type , description) VALUES ('$faculty_id','$author','$type', '$description')";
    if(mysqli_query($conn,$sqlInsert)){
        session_start();
        $_SESSION["create"] = "Успешно добавлено!";
        header("Location:index.php");
    }else{
        die("Что-то пошло не так");
    }
}
if (isset($_POST["edit"])) {
    $faculty_id = mysqli_real_escape_string($conn, $_POST["faculty_id"]);
    $type = mysqli_real_escape_string($conn, $_POST["type"]);
    $author = mysqli_real_escape_string($conn, $_POST["author"]);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);
    $id = mysqli_real_escape_string($conn, $_POST["id"]);
    $sqlUpdate = "UPDATE books SET faculty_id = '$faculty_id', type = '$type', author = '$author', description = '$description' WHERE id='$id'";
    if(mysqli_query($conn,$sqlUpdate)){
        session_start();
        $_SESSION["update"] = "Успешно обновлено!";
        header("Location:index.php");
    }else{
        die("Что-то пошло не так");
    }
}
?>