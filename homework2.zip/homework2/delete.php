<?php
if (isset($_GET['id'])) {
include("connect.php");
$id = $_GET['id'];
$sql = "DELETE FROM books WHERE id='$id'";
if(mysqli_query($conn,$sql)){
    session_start();
    $_SESSION["delete"] = "Успешно удалено!";
    header("Location:index.php");
}else{
    die("Что-то пошло не так");
}
}else{
    echo "Не выбрано";
}
?>