<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Homework1</title>
  
  <html>  
<body> 

 <div class="container">
         <form class="form-inline">
            <div class="form-group">
               <label for="date1">Начальная дата</label>
               <input type="date" value="2023-09-01" />
            </div>
            <div class="form-group">
               <label for="date2">Конечная дата</label>
               <input type="date" value="2023-10-03" />
            </div>
            <button type="submit" class="btn btn-default">Отправка данных</button>
         </form>
      </div>
	  
<?php 

$dt1 = "01-09-2023";
$dt2 = "03-10-2023";

$tm1 = strtotime($dt1);
$tm2 = strtotime($dt2);

$dt = Array ();
for($i=$tm1; $i<=$tm2;$i=$i+86400) {
if(date("w",$i) == 6) {
	$dt[] = date("l Y-m-d ", $i);
	}
	if(date("w",$i) == 0) {
	$dt[] = date("l Y-m-d ", $i);
	}
}
echo "Кол-во выходных дней - ".count($dt)."<br>";
for($i=0;$i<count($dt);$i++) {
echo $dt[$i]."<br>";
}
?>

</body>  
</html>  
