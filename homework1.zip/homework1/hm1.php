<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Homework1</title>
  
  <html>  
<body>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="start_date">Начальная дата:</label>
        <input type="date" name="start_date" id="start_date" required><br><br>
        <label for="end_date">Конечная дата:</label>
        <input type="date" name="end_date" id="end_date" required><br><br>
        <input type="submit" value="Рассчитать">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $start_date = $_POST["start_date"];
        $end_date = $_POST["end_date"];

        $start = strtotime($start_date);
        $end = strtotime($end_date);

        $weekend_days = 0;

        while ($start <= $end) {
            $day = date("N", $start);
            if ($day == 6 || $day == 7) {
                $weekend_days++;
            }
            $start = strtotime("+1 day", $start);
        }

        echo "Количество выходных дней: " . $weekend_days;
    }
    ?>
</body>
</html>
