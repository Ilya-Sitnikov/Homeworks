<?php_egg_logo_guid

include("index.php");

?>

<div class="row">
	<div class="col-md-12">
		<br><br>
		
		<h2>Товары</h2>
<table width="50%">
    <tr>
        <th>Название</th>
        <th>Товар</th>
        <th>Цена</th>
    </tr>
    <tr>
        <td>Наушники модель XYZ</td>
        <td><img src="headphones.jpg" alt="Headphones" width="100px"></td>
        <td>50$</td>
    </tr>
    <tr>
        <td>Микрофон модель XYZ</td>
        <td><img src="micro.jpg" alt="Micro" width="100px"></td>
        <td>50$</td>
    </tr>
    <tr>
        <td>Колонки XYZ</td>
        <td><img src="speakers.jpg" alt="Speakers" width="100px"></td>
        <td>100$</td>
    </tr>
    <tr>
        <td>Усилитель XYZ</td>
        <td><img src="amplifier.jpg" alt="Amplifier" width="100px"></td>
        <td>100$</td>
    </tr>
</table>
	</div>
</div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
</body>
</html>