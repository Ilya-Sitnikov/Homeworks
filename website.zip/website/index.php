<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>Starter Template for Bootstrap 3.3.2</title>
	<link rel="shortcut icon" href="">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">
	<style>body{padding-top:50px;}startertemplate{padding:40px 15px;text-align:center;}</style>
	
</head>

<body>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
<div class="container">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="#">Магазин профессиональной аудиотехники</a>
	</div>
	
	<div class="collapse navbar-collapse">
		<ul class="nav navbar-nav">
			<li class="active"><a href="index.php">Домашняя</a></li>
			<li><a href="card.php">Товары</a></li>
						<li><a href="dostavka.php">Доставка</a></li>
			<li><a href="about.php">О нас</a></li>
			<li><a href="contacts.php">Контакты</a></li>
		</ul>
	</div>
</div>
</nav>

<div class="container">
<h1>Разделы:</h1>
<div class="row">
	<div class="col-md-12">
		<br><br>
		<h2>Товары:</h2>
		<p>Здесь отображаются наши товары</p>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<br><br>
		<h2>Доставка:</h2>
		<p>Информация о способах доставки</p>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<br><br>
		<h2>О нас:</h2>
		<p>Описание нашей компании и магазина</p>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<br><br>
		<h2>Контакты:</h2>
		<p>Как связаться с нами</p>
	</div>
</div>
</div>
