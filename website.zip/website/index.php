<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8"> 	
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  	
    <meta name="description" content="Магазин профессиональной аудиотехники"> 	
    <meta name="keywords" content="аудиотехника, магазин, профессиональная"> 	
    <title>Магазин аудиотехники</title>
	
	 <style>
      
        .navbar {
            background-color: #333;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
    </style>
	
</head>
<body>
    <header>
        <h1>Магазин аудиотехники</h1> 
    </header>
    <div class="navbar">
       <a href="index.php">Главная</a>
		<a href="about.php">О нас</a>
        <a href="products.php">Товары</a>
        <a href="contact.php">Контакты</a>
        <a href="blog.php">Блог</a>
    </div>
    <main>
        <h2>Добро пожаловать в наш магазин аудиотехники!</h2>
        <p>Мы предлагаем широкий ассортимент профессиональной аудиотехники для любых целей.</p>
    </main>
    <footer>
        <p>&copy; 2024 Магазин аудиотехники. Все права защищены.</p>
    </footer> 
</body>
</html>
