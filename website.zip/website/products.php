<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta name="description" content="Товары - Магазин аудиотехники"> 
    <meta name="keywords" content="аудиотехника, магазин, профессиональная, товары">
    <title>Товары - Магазин аудиотехники</title>
	
	<style>
      
        .navbar {
            background-color: #333;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
    </style>
	
</head>
<body>
    <header>
        <h1>Товары</h1>
    </header>
    <div class="navbar">
       <a href="index.php">Главная</a>
		<a href="about.php">О нас</a>
        <a href="products.php">Товары</a>
        <a href="contact.php">Контакты</a>
        <a href="blog.php">Блог</a>
    </div>
    <main>
        <h2>Выберите из нашего широкого ассортимента</h2>
        <p>У нас вы найдете все необходимое для создания и настройки профессиональной звуковой системы.</p>
    </main>
	
	<table>
        <tr>
            <th>Товар</th>
            <th>Цена</th>
            <th>Фото</th>
        </tr>
        <tr>
            <td>Наушники:</td>
            <td>1000 рублей</td>
            <td><img src="наушники.jpg" alt="Наушники"></td>
        </tr>
        <tr>
            <td>Микрофон:</td>
            <td>2000 рублей</td>
            <td><img src="микрофон.jpg" alt="Микрофон"></td>
        </tr>
        <tr>
            <td>Акустика:</td>
            <td>5000 рублей</td>
            <td><img src="акустика.jpg" alt="Акустическая система"></td>
        </tr>
    </table>
	
    <footer>
        <p>&copy; 2024 Магазин аудиотехники. Все права защищены.</p>
    </footer>
</body>
</html>
