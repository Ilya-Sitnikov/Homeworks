<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8"> <!--  <p> Мета-тег, указывающий кодировку страницы (UTF-8).</p> --> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!--  <p>Мета-тег, определяющий масштабирование страницы для мобильных устройств.</p> --> 
    <meta name="description" content="О нас - Магазин аудиотехники"> <!--  <p>Мета-тег, содержащий описание страницы для поисковых систем.</p> --> 
    <meta name="keywords" content="аудиотехника, магазин, профессиональная, о нас"> <!--  <p>Мета-тег, который используется для указания списка ключевых слов, релевантных для конкретной страницы.</p> --> 
    <title>О нас - Магазин аудиотехники</title>
	
	<style>
      
        .navbar {
            background-color: #333;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
    </style>
	
</head>
<body>
    <header>
        <h1>О нас</h1>
    </header>
    <div class="navbar">
       <a href="index.php">Главная</a>
		<a href="about.php">О нас</a>
        <a href="products.php">Товары</a>
        <a href="contact.php">Контакты</a>
        <a href="blog.php">Блог</a>
    </div>
    <main>
        <h2>Мы - профессионалы в области аудиотехники</h2>
        <p>Наш магазин предлагает только качественную и проверенную аудиотехнику от ведущих производителей.</p>
    </main>
    <footer>
        <p>&copy; 2024 Магазин аудиотехники. Все права защищены.</p>
    </footer>
</body>
</html>
