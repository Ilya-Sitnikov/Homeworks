<?php_egg_logo_guid

include("index.php");

?>

<div class="row">
	<div class="col-md-12">
		<br><br>
		
		<h2>О нас</h2>
		<p>Магазин профессиональной аудиотехники предлагает широкий ассортимент высококачественных звуковых систем,</p>
		<p>музыкальных инструментов и оборудования для студий записи и звукозаписи.</p>
		<p>Наша цель - предоставить профессиональным музыкантам и аудиоинженерам лучшее оборудование для их творчества.</p>
	</div>
</div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
</body>
</html>