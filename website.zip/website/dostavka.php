<?php_egg_logo_guid

include("index.php");

?>

<div class="row">
	<div class="col-md-12">
		<br><br>
		
		<h1>Доставка и оплата</h1>
		<h2>Доставка</h2>
		<p>Мы предлагаем доставку по всей России. Сроки и стоимость доставки зависят от вашего региона и выбранного способа доставки.</p>
		<h2>Способы оплаты</h2>
		<p>Мы принимаем оплату банковскими картами, электронными деньгами и наличными при получении заказа. Выберите наиболее удобный для вас способ оплаты при оформлении заказа.</p>
	</div>
</div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
</body>
</html>