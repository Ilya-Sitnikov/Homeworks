<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Блог - Магазин аудиотехники"> 
    <meta name="keywords" content="аудиотехника, магазин, профессиональная, блог">  
    <title>Блог - Магазин аудиотехники</title>
	
	<style>
      
        .navbar {
            background-color: #333;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }
    </style>
	
</head>
<body>
    <header>
        <h1>Блог</h1>
    </header>
    <div class="navbar">
       <a href="index.php">Главная</a>
		<a href="about.php">О нас</a>
        <a href="products.php">Товары</a>
        <a href="contact.php">Контакты</a>
        <a href="blog.php">Блог</a>
    </div>
    <main>
        <h2>Последние новости и статьи</h2>
        <p>В нашем блоге вы найдете полезные статьи и новости из мира аудиотехники.</p>
		<p>http//vk.com/site</p>
    </main>
    <footer>
        <p>&copy; 2024 Магазин аудиотехники. Все права защищены.</p>
    </footer>
</body>
</html>
