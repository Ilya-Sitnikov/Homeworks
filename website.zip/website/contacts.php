<?php_egg_logo_guid

include("index.php");

?>

<div class="row">
	<div class="col-md-12">
		<br><br>
		
		<h2>Контакты</h2>
		<p>Адрес: ул. Примерная, д. 123, г. Примерный</p>
		<p>Телефон: +7 (123) 456-7890</p>
		<p>Email: info@example.com</p>
	</div>
</div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
</body>
</html>