<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Homework3</title>
  
<html>  
<body>  

<form method="post">  
Ввести первое цисло:  
<input type="number" name="number1" /><br><br>  
Ввести второе число:  
<input type="number" name="number2" /><br><br>  
<input  type="submit" name="submit" value="Посчитать">  
</form>  

<?php  
    if(isset($_POST['submit']))  
    {  
        $number1 = $_POST['number1'];  
        $number2 = $_POST['number2'];  
        $mul =  $number1*$number2; 
		$sum =  $number1+$number2;		
echo "произведение этих двух чисел: ".$mul."<br>"; 
echo "сумма этих двух чисел: ".$sum."<br>"; 
}  
  $c=0;
for($i=$number1; $i<=$number2;$i++) {
	
	if ($i%9==0) {
		$c++;
		
	}

}

echo "сколько чисел в промежутке между первым и вторым числом нацело делится на 9: ".$c;	

?>

</body>  
</html>  